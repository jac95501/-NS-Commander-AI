*Place all files into amxmodx/data*

My building placement rules are as follows:

*1 Command station at marine start and all hive locations.
*1 IP at marine start, 2 at all hive locations.
*1 Armory at marine start and all hive locations.
*1 Arms Lab at marine start.
*1 Observatory at marine start.
*1 Prototype Lab at marine start.
*1 Phase Gate at marine start and all hive locations.
*1 Turret factory at marine start, Resource nodes, and all hive locations.
*6 Turrets at marine start, and all hive locations.
*4 Turrets at all Resource nodes.
*2 Turrets at siege points.
*2 Siege Cannons at all hive locations and siege points.
